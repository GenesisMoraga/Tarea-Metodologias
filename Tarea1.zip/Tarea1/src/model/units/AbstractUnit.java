package model.units;

import static java.lang.Math.max;
import static java.lang.Math.min;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import model.items.*;
import model.map.Location;

/**
 * This class represents an abstract unit.
 * <p>
 * An abstract unit is a unit that cannot be used in the
 * game, but that contains the implementation of some of the methods that are common for most
 * units.
 *
 * @author Ignacio Slater Muñoz
 * @since 1.0
 */
public abstract class AbstractUnit implements IUnit {

  protected final List<IEquipableItem> items = new ArrayList<>();
  private int maxHitPoints;
  private int currentHitPoints;
  private final int movement;
  protected IEquipableItem equippedItem;
  private Location location;
  private boolean vive;

  /**
   * Creates a new Unit.
   *
   * @param hitPoints
   *     the maximum amount of damage a unit can sustain
   * @param movement
   *     the number of panels a unit can move
   * @param location
   *     the current position of this unit on the map
   * @param maxItems
   *     maximum amount of items this unit can carry
   */
  protected AbstractUnit(final int hitPoints, final int movement,
      final Location location, final int maxItems, final IEquipableItem... items) {
    this.maxHitPoints=hitPoints;
    this.currentHitPoints = hitPoints;
    this.movement = movement;
    this.location = location;
    this.items.addAll(Arrays.asList(items).subList(0, min(maxItems, items.length)));
    this.vive=true;
  }


  @Override
  public int getCurrentHitPoints() {
    return currentHitPoints;
  }

  @Override
  public List<IEquipableItem> getItems() {
    return List.copyOf(items);
  }

  @Override
  public IEquipableItem getEquippedItem() {
    return equippedItem;
  }

  @Override
  public void setEquippedItem(final IEquipableItem item) {
    this.equippedItem = item;
  }

  @Override
  public Location getLocation() {
    return location;
  }

  @Override
  public void setLocation(final Location location) {
    this.location = location;
  }

  @Override
  public int getMovement() {
    return movement;
  }

  @Override
  public void moveTo(final Location targetLocation) {
    if (getLocation().distanceTo(targetLocation) <= getMovement()
        && targetLocation.getUnit() == null) {
      setLocation(targetLocation);
    }
  }

  public boolean estaVivo(){return vive;}

  public boolean equipableItemVacio(){
      return equippedItem == null;
  }

  @Override
  public void attack(IUnit other) {
    if(!(equipableItemVacio()) && this.location.distanceTo(other.getLocation())<=equippedItem.getMaxRange() &&
            this.location.distanceTo(other.getLocation())>=equippedItem.getMinRange() && this.estaVivo() && other.estaVivo()){
      equippedItem.attack(other);
    }
  }

  @Override
  public void counterAttack(IUnit other) {
    if(!(equipableItemVacio()) && this.location.distanceTo(other.getLocation())<=equippedItem.getMaxRange() &&
            this.location.distanceTo(other.getLocation())>=equippedItem.getMinRange() && this.estaVivo() && other.estaVivo()){
      equippedItem.counterAttack(other);
    }
  }

  public void recibeAttack(IEquipableItem item) {
    this.currentHitPoints -= item.getPower();
    this.muriendose();
    this.counterAttack(item.getOwner());
  }

  public void recibeWeaknessAttack(IEquipableItem item) {
    this.currentHitPoints -= (int)(item.getPower() * 1.5);
    this.muriendose();
    this.counterAttack(item.getOwner());
  }

  public void recibeResistantAttack(IEquipableItem item) {
    this.currentHitPoints -= Math.max(item.getPower()-20, 0);
    this.muriendose();
    this.counterAttack(item.getOwner());
  }

  public void recibeCounterAttack(IEquipableItem item) {
    this.currentHitPoints -= item.getPower();
    this.muriendose();
  }

  public void recibeWeaknessCounterAttack(IEquipableItem item) {
    this.currentHitPoints -= (int)(item.getPower() * 1.5);
    this.muriendose();
  }

  public void recibeResistantCounterAttack(IEquipableItem item) {
    this.currentHitPoints -= Math.max(item.getPower()-20,0);
    this.muriendose();
  }

  public void recibeCura(IEquipableItem item){
    this.currentHitPoints+= item.getPower();
    this.sanandose();
  }

  protected void muriendose(){
    if (this.getCurrentHitPoints()<=0){
      this.currentHitPoints=0;
      this.vive=false;
    }
  }

  protected void sanandose(){
    if(this.currentHitPoints>this.maxHitPoints){
      this.currentHitPoints=this.maxHitPoints;
    }
  }



  @Override
  public void daItem(IUnit other, IEquipableItem item){
    if (this.tieneItem(item) && other.tieneEspacio() && getLocation().distanceTo(other.getLocation())==1) {
      this.removerItem(item);
      item.setOwner(other);
      other.agregarItem(item);
    }
  }

  protected void removerItem(IEquipableItem item){
    items.remove(item);
  }

  protected  boolean tieneItem(IEquipableItem item){
    List<IEquipableItem> lista=getItems();
    for(int i=0;i<lista.size();i++) {
      if(lista.get(i).equals(item)){return true;}
    }
    return false;
  }

  public boolean tieneEspacio(){
    return items.size()<3;
  }

  public void agregarItem(IEquipableItem item){
    items.add(item);
  }
}
