package model.items;

import model.units.IUnit;


public class MagicBookAnima extends ItemMagico {
    /**
     * Constructor for a default item without any special behaviour.
     *
     * @param name     the name of the item
     * @param power    the power of the item (this could be the amount of damage or healing the item does)
     * @param minRange the minimum range of the item
     * @param maxRange
     */
    public MagicBookAnima(String name, int power, int minRange, int maxRange) {
        super(name, power, minRange, maxRange);
    }

    @Override
    public void attack(IUnit recibidor) {
        if(recibidor.equipableItemVacio()){
            recibidor.recibeAttack(this);
        }else{
            recibidor.getEquippedItem().recibeMagicBookAnimaAttack(this);
        }
    }

    @Override
    public void counterAttack(IUnit recibidor) {
        if(recibidor.equipableItemVacio()){
            recibidor.recibeCounterAttack(this);
        }else{
            recibidor.getEquippedItem().recibeMagicBookAnimaCounterAttack(this);
        }
    }


    @Override
    public void recibeMagicBookLuzAttack(MagicBookLuz book) {
        this.getOwner().recibeResistantAttack(book);
    }

    @Override
    public void recibeMagicBookOscuridadAttack(MagicBookOscuridad book) {
        this.getOwner().recibeWeaknessAttack(book);
    }

    @Override
    public void recibeMagicBookLuzCounterAttack(MagicBookLuz book) {
        this.getOwner().recibeResistantCounterAttack(book);
    }

    @Override
    public void recibeMagicBookOscuridadCounterAttack(MagicBookOscuridad book) {
        this.getOwner().recibeWeaknessCounterAttack(book);
    }

}
