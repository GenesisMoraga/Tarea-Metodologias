package model.items;

import model.units.IUnit;

/**
 * This class represents a <i>spear</i>.
 * <p>
 * Spears are strong against swords and weak against axes
 *
 * @author Ignacio Slater Muñoz
 * @since 1.0
 */
public class Spear extends ItemNoMagico {

  /**
   * Creates a new Axe item
   *
   * @param name
   *     the name of the Axe
   * @param power
   *     the damage of the axe
   * @param minRange
   *     the minimum range of the axe
   * @param maxRange
   *     the maximum range of the axe
   */
  public Spear(final String name, final int power, final int minRange, final int maxRange) {
    super(name, power, minRange, maxRange);
  }

  @Override
  public void attack(IUnit recibidor) {
    if(recibidor.equipableItemVacio()){
      recibidor.recibeAttack(this);
    }else{
      recibidor.getEquippedItem().recibeSpearAttack(this);
    }
  }

  @Override
  public void counterAttack(IUnit recibidor) {
    if(recibidor.equipableItemVacio()){
      recibidor.recibeCounterAttack(this);
    }else{
      recibidor.getEquippedItem().recibeSpearCounterAttack(this);
    }
  }

  @Override
  public void recibeAxeAttack(Axe axe) {
    this.getOwner().recibeWeaknessAttack(axe);
  }

  @Override
  public void recibeSwordAttack(Sword sword) {
    this.getOwner().recibeResistantAttack(sword);
  }

  @Override
  public void recibeAxeCounterAttack(Axe axe) {
    this.getOwner().recibeWeaknessCounterAttack(axe);
  }

  @Override
  public void recibeSwordCounterAttack(Sword sword) {
    this.getOwner().recibeResistantCounterAttack(sword);
  }

  @Override
  public void equipateEnHero(IUnit unit){
    unit.setEquippedItem(this);
  }

}
