package model.items;

import model.units.IUnit;
import model.units.SwordMaster;

/**
 * This interface represents the <i>weapons</i> that the units of the game can use.
 * <p>
 * The signature for all the common methods of the weapons are defined here. Every weapon have a
 * base damage and is strong or weak against other type of weapons.
 *
 * @author Ignacio Slater Muñoz
 * @since 1.0
 */
public interface IEquipableItem {

  /**
   * Equips this item to a unit.
   *
   * @param unit
   *     the unit that will be quipped with the item
   */
  void equipTo(IUnit unit);

  /**
   * @return the unit that has currently equipped this item
   */
  IUnit getOwner();

  /**
   * @return the name of the item
   */
  String getName();

  /**
   * @return the power of the item
   */
  int getPower();

  /**
   * @return the minimum range of the item
   */
  int getMinRange();

  /**
   * @return the maximum range of the item
   */
  int getMaxRange();


  void attack(IUnit other);

  void counterAttack(IUnit other);

  void setOwner(IUnit other);

  void equipateEnAlpaca(IUnit unit);

  void equipateEnArcher(IUnit unit);

  void equipateEnCleric(IUnit unit);

  void equipateEnFighter(IUnit unit);

  void equipateEnHero(IUnit unit);

  void equipateEnSorcerer(IUnit unit);

  void equipateEnSwordMaster(IUnit unit);

  void recibeAxeAttack(Axe axe);

  void recibeBowAttack(Bow bow);

  void recibeSpearAttack(Spear spear);

  void recibeSwordAttack(Sword sword);

  void recibeMagicBookAnimaAttack(MagicBookAnima magicBookAnima);

  void recibeMagicBookLuzAttack(MagicBookLuz magicBookLuz);

  void recibeMagicBookOscuridadAttack(MagicBookOscuridad magicBookOscuridad);


  void recibeAxeCounterAttack(Axe axe);

  void recibeBowCounterAttack(Bow bow);

  void recibeSpearCounterAttack(Spear spear);

  void recibeSwordCounterAttack(Sword sword);

  void recibeMagicBookAnimaCounterAttack(MagicBookAnima magicBookAnima);

  void recibeMagicBookLuzCounterAttack(MagicBookLuz magicBookLuz);

  void recibeMagicBookOscuridadCounterAttack(MagicBookOscuridad magicBookOscuridad);
}
