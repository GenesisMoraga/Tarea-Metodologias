package model.items;

import model.units.IUnit;

/**
 * Abstract class that defines some common information and behaviour between all items.
 *
 * @author Ignacio Slater Muñoz
 */
public abstract class AbstractItem implements IEquipableItem {

  private final String name;
  private final int power;
  protected int maxRange;
  protected int minRange;
  private IUnit owner;

  /**
   * Constructor for a default item without any special behaviour.
   *
   * @param name
   *     the name of the item
   * @param power
   *     the power of the item (this could be the amount of damage or healing the item does)
   * @param minRange
   *     the minimum range of the item
   * @param maxRange
   *     the maximum range of the item
   */
  public AbstractItem(final String name, final int power, final int minRange, final int maxRange) {
    this.name = name;
    this.power = power;
    this.minRange = Math.max(minRange, 1);
    this.maxRange = Math.max(maxRange, this.minRange);
  }

  @Override
  public void equipTo(final IUnit unit) {
    unit.setEquippedItem(this);
    owner = unit;
  }

  @Override
  public IUnit getOwner() {
    return owner;
  }

  @Override
  public String getName() {
    return name;
  }

  @Override
  public int getPower() {
    return power;
  }

  @Override
  public int getMinRange() {
    return minRange;
  }

  @Override
  public int getMaxRange() {
    return maxRange;
  }

  @Override
  public void setOwner(IUnit unit){
    owner=unit;
  }

  @Override
  public void equipateEnAlpaca(IUnit unit){}

  @Override
  public void equipateEnArcher(IUnit unit){}

  @Override
  public void equipateEnCleric(IUnit unit){}

  @Override
  public void equipateEnFighter(IUnit unit){}

  @Override
  public void equipateEnHero(IUnit unit){}

  @Override
  public void equipateEnSorcerer(IUnit unit){}

  @Override
  public void equipateEnSwordMaster(IUnit unit){}


  @Override
  public void recibeAxeAttack(Axe axe){
    getOwner().recibeAttack(axe);
  }

  @Override
  public void recibeBowAttack(Bow bow){
    getOwner().recibeAttack(bow);
  }

  @Override
  public void recibeSpearAttack(Spear spear) {
    getOwner().recibeAttack(spear);
  }

  @Override
  public void recibeSwordAttack(Sword sword){
    getOwner().recibeAttack(sword);
  }

  @Override
  public void recibeMagicBookAnimaAttack(MagicBookAnima magicBookAnima){
    getOwner().recibeAttack(magicBookAnima);
  }

  @Override
  public void recibeMagicBookLuzAttack(MagicBookLuz magicBookLuz){
      getOwner().recibeAttack(magicBookLuz);
  }

  @Override
  public void recibeMagicBookOscuridadAttack(MagicBookOscuridad magicBookOscuridad){
    getOwner().recibeAttack(magicBookOscuridad);
  }



  public void recibeAxeCounterAttack(Axe axe){
    getOwner().recibeCounterAttack(axe);
  }


  public void recibeBowCounterAttack(Bow bow){
    getOwner().recibeCounterAttack(bow);
  }

  public void recibeSpearCounterAttack(Spear spear){
    getOwner().recibeCounterAttack(spear);
  }



  public void recibeSwordCounterAttack(Sword sword){
    getOwner().recibeCounterAttack(sword);
  }


  public void recibeMagicBookAnimaCounterAttack(MagicBookAnima magicBookAnima){
    getOwner().recibeCounterAttack(magicBookAnima);
  }


  public void recibeMagicBookLuzCounterAttack(MagicBookLuz magicBookLuz){
    getOwner().recibeCounterAttack(magicBookLuz);
  }


  public void recibeMagicBookOscuridadCounterAttack(MagicBookOscuridad magicBookOscuridad){
    getOwner().recibeCounterAttack(magicBookOscuridad);
  }


}
