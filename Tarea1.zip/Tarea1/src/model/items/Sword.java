package model.items;

import model.units.IUnit;

/**
 * This class represents a sword type item.
 * <p>
 * Swords are strong against axes and weak against spears.
 *
 * @author Ignacio Slater Muñoz
 * @since 1.0
 */
public class Sword extends ItemNoMagico {

  /**
   * Creates a new Sword.
   *
   * @param name
   *     the name that identifies the weapon
   * @param power
   *     the base damage pf the weapon
   * @param minRange
   *     the minimum range of the weapon
   * @param maxRange
   *     the maximum range of the weapon
   */
  public Sword(final String name, final int power, final int minRange, final int maxRange) {
    super(name, power, minRange, maxRange);
  }

  public void attack(IUnit recibidor) {
    if(recibidor.equipableItemVacio()){
      recibidor.recibeAttack(this);
    }else{
      recibidor.getEquippedItem().recibeSwordAttack(this);
    }
  }

  public void counterAttack(IUnit recibidor) {
    if(recibidor.equipableItemVacio()){
      recibidor.recibeCounterAttack(this);
    }else{
      recibidor.getEquippedItem().recibeSwordCounterAttack(this);
    }
  }

  @Override
  public void recibeAxeAttack(Axe axe) {
    this.getOwner().recibeResistantAttack(axe);
  }

  @Override
  public void recibeSpearAttack(Spear spear) {
    this.getOwner().recibeWeaknessAttack(spear);
  }

  @Override
  public void recibeAxeCounterAttack(Axe axe) {
    this.getOwner().recibeResistantCounterAttack(axe);
  }

  @Override
  public void recibeSpearCounterAttack(Spear spear) {
    this.getOwner().recibeWeaknessCounterAttack(spear);
  }


  @Override
  public void equipateEnSwordMaster(IUnit unit) {
    unit.setEquippedItem(this);
  }
}
