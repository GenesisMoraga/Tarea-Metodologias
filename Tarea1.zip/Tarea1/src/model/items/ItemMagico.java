package model.items;

import model.units.IUnit;

public class ItemMagico extends AbstractItem {
    /**
     * Constructor for a default item without any special behaviour.
     *
     * @param name     the name of the item
     * @param power    the power of the item (this could be the amount of damage or healing the item does)
     * @param minRange the minimum range of the item
     * @param maxRange
     */
    public ItemMagico(String name, int power, int minRange, int maxRange) {
        super(name, power, minRange, maxRange);
    }

    @Override
    public void attack(IUnit other) {
    }

    @Override
    public void counterAttack(IUnit other){

    }

    @Override
    public void recibeAxeAttack(Axe axe) {
        this.getOwner().recibeWeaknessAttack(axe);
    }

    @Override
    public void recibeBowAttack(Bow bow) {
        this.getOwner().recibeWeaknessAttack(bow);
    }

    @Override
    public void recibeSpearAttack(Spear spear) {
        this.getOwner().recibeWeaknessAttack(spear);
    }

    @Override
    public void recibeSwordAttack(Sword sword) {
        this.getOwner().recibeWeaknessAttack(sword);
    }

    @Override
    public void recibeAxeCounterAttack(Axe axe) {
        this.getOwner().recibeWeaknessCounterAttack(axe);
    }

    @Override
    public void recibeBowCounterAttack(Bow bow) {
        this.getOwner().recibeWeaknessCounterAttack(bow);
    }

    @Override
    public void recibeSpearCounterAttack(Spear spear) {
        this.getOwner().recibeWeaknessCounterAttack(spear);
    }

    @Override
    public void recibeSwordCounterAttack(Sword sword) {
        this.getOwner().recibeWeaknessCounterAttack(sword);
    }


    @Override
    public void equipateEnSorcerer(IUnit unit){
        unit.setEquippedItem(this);
    }
}
