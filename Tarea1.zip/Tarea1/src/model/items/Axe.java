package model.items;

import model.units.IUnit;

/**
 * This class represents an Axe.
 * <p>
 * Axes are strong against spears but weak agains swords.
 *
 * @author Ignacio Slater Muñoz
 * @since 1.0
 */
public class Axe extends ItemNoMagico {

  /**
   * Creates a new Axe item
   *
   * @param name
   *     the name of the Axe
   * @param power
   *     the damage of the axe
   * @param minRange
   *     the minimum range of the axe
   * @param maxRange
   *     the maximum range of the axe
   */
  public Axe(final String name, final int power, final int minRange, final int maxRange) {
    super(name, power, minRange, maxRange);
  }

  @Override
  public void attack(IUnit recibidor) {
      if(recibidor.equipableItemVacio()){
          recibidor.recibeAttack(this);
      }else{
          recibidor.getEquippedItem().recibeAxeAttack(this);
      }
  }

  @Override
  public void counterAttack(IUnit recibidor) {
      if(recibidor.equipableItemVacio()){
          recibidor.recibeCounterAttack(this);
      }else{
          recibidor.getEquippedItem().recibeAxeCounterAttack(this);
      }
  }

  @Override
  public void recibeSpearAttack(Spear spear) {
      this.getOwner().recibeResistantAttack(spear);
  }

  @Override
  public void recibeSwordAttack(Sword sword) {
      this.getOwner().recibeWeaknessAttack(sword);
  }

  @Override
  public void recibeSpearCounterAttack(Spear spear) {
      this.getOwner().recibeResistantCounterAttack(spear);
  }

  @Override
  public void recibeSwordCounterAttack(Sword sword) {
      this.getOwner().recibeWeaknessCounterAttack(sword);
  }

 @Override
  public void equipateEnFighter(IUnit unit){
    unit.setEquippedItem(this);
 }

}
