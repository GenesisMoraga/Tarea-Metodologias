package model.items;

import model.map.Location;
import model.units.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Test set for Axes
 *
 * @author Ignacio Slater Muñoz
 * @since 1.0
 */
class AxeTest extends AbstractTestItem {

  private Axe axe;
  private Axe wrongAxe;
  private Fighter fighter;




  @Override
  public void setTestItem() {
    expectedName = "Common axe";
    expectedPower = 10;
    expectedMinRange = 1;
    expectedMaxRange = 2;
    axe = new Axe(expectedName, expectedPower, expectedMinRange, expectedMaxRange);
  }

  /**
   * Sets up an item with wrong ranges setted.
   */
  @Override
  public void setWrongRangeItem() {
    wrongAxe = new Axe("Wrong axe", 0, -1, -2);
  }

  /**
   * Sets the unit that will be equipped with the test item
   */
  @Override
  public void setTestUnit() {
    fighter = new Fighter(10, 5, new Location(0, 0));
  }

  @Override
  public IEquipableItem getWrongTestItem() {
    return wrongAxe;
  }

  @Override
  public IEquipableItem getTestItem() {
    return axe;
  }

  /**
   * @return a unit that can equip the item being tested
   */
  @Override
  public IUnit getTestUnit() {
    return fighter;
  }

 /*
  @BeforeEach
  public void setUp() {
    alpacat = new Alpaca(50,3,new Location(1,1), null);
    alpacat.setEquippedItem(alpacat.getItems().get(0));
    archert = new Archer(30, 1, new Location(0,0), new Bow("bo",5,1,3) );
    archert.setEquippedItem(archert.getItems().get(0));
    clerict = new Cleric(45, 2, new Location(1,2), new Staff("st",10,2,3));
    clerict.setEquippedItem(clerict.getItems().get(0));
    fightert = new Fighter(25, 3, new Location(0,1), new Axe("ax",22,0,4));
    fightert.setEquippedItem(fightert.getItems().get(0));
    herot = new Hero(32, 1, new Location(2,1), new Spear("sp",25,2,4));
    herot.setEquippedItem(herot.getItems().get(0));
    sorcerert= new Sorcerer(40,2,new Location(1,0), new MagicBookAnima("mb",13,1,2));
    sorcerert.setEquippedItem(sorcerert.getItems().get(0));
    swordmastert= new SwordMaster(20,1, new Location(2,2),new Sword("sw",25,1,4));
    swordmastert.setEquippedItem(swordmastert.getItems().get(0));
  }

  */
/*
  @Test
  public void attackTest(){
    axe.setOwner(fighter);
    axe.attack(sorcerert);
    assertEquals(25,alpacat.getCurrentHitPoints());
}
*/




}