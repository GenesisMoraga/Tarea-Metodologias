package model.items;

import model.map.Location;
import model.units.Archer;
import model.units.Cleric;
import model.units.IUnit;
import model.units.Sorcerer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class MagicBookAnimaTest {
    private IUnit
            cleric,
            archer,
            sorcererA,
            sorcererL,
            sorcererO;
    private MagicBookAnima mba;
    private MagicBookLuz mbl;
    private MagicBookOscuridad mbo;
    private Staff st;
    private Bow bw;

    @BeforeEach
    public void setUp() {
        st=new Staff("st",12,1,3);
        bw= new Bow("bw",20,2,4);
        mba= new MagicBookAnima("a",10,1,3);
        mbl=  new MagicBookLuz("l",15,1,4);
        mbo= new MagicBookOscuridad("o",25,1,2);
        cleric = new Cleric(50,1, new Location(1,0), st);
        archer= new Archer(30,2,new Location(0,0),bw);
        sorcererA= new Sorcerer(30,1,new Location(1,0),mba);
        sorcererL= new Sorcerer(45,3,new Location(1,1),mbl);
        sorcererO= new Sorcerer(50,3,new Location(1,2),mbo);

        bw.setOwner(archer);
        st.setOwner(cleric);
        mba.setOwner(sorcererA);
        mbl.setOwner(sorcererL);
        mbo.setOwner(sorcererO);

        cleric.setEquippedItem(st);
        archer.setEquippedItem(bw);
        sorcererA.setEquippedItem(mba);
        sorcererO.setEquippedItem(mbo);
        sorcererL.setEquippedItem(mbl);
    }

    @Test
    public void constTest() {
        assertEquals(10,mba.getPower());
        assertEquals(1,mba.getMinRange());
        assertEquals(3,mba.getMaxRange());
    }

    @Test
    public void attackTest() {
        mba.attack(sorcererL);
        assertEquals(30,sorcererL.getCurrentHitPoints());
        assertEquals(30,sorcererA.getCurrentHitPoints());
    }

    @Test
    public void counterAttack() {
        mba.attack(sorcererO);
        assertEquals(50,sorcererO.getCurrentHitPoints());
        assertEquals(30, sorcererA.getCurrentHitPoints());
    }


    @Test
    public void recibeMagicBookLuzAttack() {
        mba.recibeMagicBookLuzAttack(mbl);
        assertEquals(30,sorcererA.getCurrentHitPoints());
    }

    @Test
    public void recibeMagicBookOscuridadAttack() {
        mba.recibeMagicBookOscuridadAttack(mbo);
        assertEquals(0,sorcererA.getCurrentHitPoints());
        assertEquals(50,sorcererO.getCurrentHitPoints());
    }

    @Test
    public void recibeMagicBookLuzCounterAttack() {
        mba.recibeMagicBookLuzCounterAttack(mbl);
        assertEquals(30,sorcererA.getCurrentHitPoints());
        assertEquals(45, sorcererL.getCurrentHitPoints());
    }

    @Test
    public void recibeMagicBookOscuridadCounterAttack() {
        mba.recibeMagicBookOscuridadCounterAttack(mbo);
        assertEquals(0,sorcererA.getCurrentHitPoints());
        assertEquals(50,sorcererO.getCurrentHitPoints());
    }

}
