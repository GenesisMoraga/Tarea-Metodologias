package model.items;
import model.map.Location;
import model.units.Archer;
import model.units.Cleric;
import model.units.IUnit;
import model.units.Sorcerer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class MagicBookOscuridadTest {
    private IUnit
            cleric,
            archer,
            sorcererA,
            sorcererL,
            sorcererO;
    private MagicBookAnima mba;
    private MagicBookLuz mbl;
    private MagicBookOscuridad mbo;
    private Staff st;
    private Bow bw;

    @BeforeEach
    public void setUp() {
        st = new Staff("st", 12, 2, 3);
        bw = new Bow("bw", 22, 0, 4);
        mba = new MagicBookAnima("a", 30, 1, 3);
        mbl = new MagicBookLuz("l", 20, 1, 4);
        mbo = new MagicBookOscuridad("o", 25, 1, 2);
        cleric = new Cleric(50, 1, new Location(1, 0), st);
        archer = new Archer(32, 1, new Location(0, 0), bw);
        sorcererA = new Sorcerer(50, 1, new Location(1, 0), mba);
        sorcererL = new Sorcerer(45, 1, new Location(1, 1), mbl);
        sorcererO = new Sorcerer(30, 1, new Location(1, 2), mbo);

        bw.setOwner(archer);
        st.setOwner(cleric);
        mba.setOwner(sorcererA);
        mbl.setOwner(sorcererL);
        mbo.setOwner(sorcererO);

        cleric.setEquippedItem(st);
        archer.setEquippedItem(bw);
        sorcererA.setEquippedItem(mba);
        sorcererO.setEquippedItem(mbo);
        sorcererL.setEquippedItem(mbl);
    }

    @Test
    public void constTest() {
        assertEquals(25, mbo.getPower());
        assertEquals(1, mbo.getMinRange());
        assertEquals(2, mbo.getMaxRange());
    }

    @Test
    public void attackTest() {
        mbo.attack(cleric);
        assertEquals(13, cleric.getCurrentHitPoints());

    }

    @Test
    public void counterAttackTest() {
        mbo.counterAttack(sorcererA);
        assertEquals(13, sorcererA.getCurrentHitPoints());
    }

    @Test
    public void recibeMagicBookAnimaAttackTest() {
        mbo.recibeMagicBookAnimaAttack(mba);
        assertEquals(20, sorcererO.getCurrentHitPoints());
    }

    @Test
    public void recibeMagicBookLuzAttackTest() {
        mbo.recibeMagicBookLuzAttack(mbl);
        assertEquals(0, sorcererO.getCurrentHitPoints());
    }

    @Test
    public void recibeMagicBookAnimaCounterAttackTest() {
        mbo.recibeMagicBookAnimaCounterAttack(mba);
        assertEquals(20, sorcererO.getCurrentHitPoints());
    }

    @Test
    public void recibeMagicBookLuzCounterAttackTest() {
        mbo.recibeMagicBookLuzCounterAttack(mbl);
        assertEquals(0, sorcererO.getCurrentHitPoints());
    }
}
