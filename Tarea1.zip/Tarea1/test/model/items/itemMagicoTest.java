package model.items;

import model.map.Location;
import model.units.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class itemMagicoTest {

    private IUnit
            cleric,
            archer,
            fighter,
            hero,
            sword,
            sorcererA,
            sorcererL,
            sorcererO;
    private MagicBookAnima mba;
    private MagicBookLuz mbl;
    private MagicBookOscuridad mbo;
    private Staff st;
    private Axe ax;
    private Bow bw;
    private Spear sp;
    private Sword sw;

    @BeforeEach
    public void setUp() {
        st=new Staff("st",12,1,3);
        ax= new Axe("ax",30,1,3);
        bw= new Bow("bw",20,2,4);
        sp=new Spear("sp",15,1,4);
        sw= new Sword("sw",25,1,5);
        mba= new MagicBookAnima("a",10,1,3);
        mbl=  new MagicBookLuz("l",15,1,4);
        mbo= new MagicBookOscuridad("o",25,1,2);

        cleric = new Cleric(50,1, new Location(1,0), st);
        archer= new Archer(30,1,new Location(0,0),bw);
        fighter=new Fighter(25,1,new Location(0,1),ax);
        hero=new Hero(40,1,new Location(2,2),sp);
        sword=new SwordMaster(35,1,new Location(2,1),sw);
        sorcererA= new Sorcerer(30,1,new Location(1,0),mba);
        sorcererL= new Sorcerer(45,1,new Location(1,1),mbl);
        sorcererO= new Sorcerer(50,1,new Location(1,2),mbo);

        bw.setOwner(archer);
        ax.setOwner(fighter);
        st.setOwner(cleric);
        sp.setOwner(hero);
        sw.setOwner(sword);
        mba.setOwner(sorcererA);
        mbl.setOwner(sorcererL);
        mbo.setOwner(sorcererO);

        cleric.setEquippedItem(st);
        archer.setEquippedItem(bw);
        fighter.setEquippedItem(ax);
        hero.setEquippedItem(sp);
        sword.setEquippedItem(sw);
        sorcererA.setEquippedItem(mba);
        sorcererO.setEquippedItem(mbo);
        sorcererL.setEquippedItem(mbl);
    }

    @Test
    public void recibeAxeAttackTest() {
       mba.recibeAxeAttack(ax);
       assertEquals(0,sorcererA.getCurrentHitPoints());
    }

    @Test
    public void recibeBowAttackTest(){
        mbo.recibeBowAttack(bw);
        assertEquals(20,sorcererO.getCurrentHitPoints());
    }

    @Test
    public void recibeSpearAttackTest() {
        mbl.recibeSpearAttack(sp);
        assertEquals(23,sorcererL.getCurrentHitPoints());
    }

    @Test
    public void recibeSwordAttackTest() {
        mba.recibeSwordAttack(sw);
        assertEquals(0,sorcererA.getCurrentHitPoints());
    }

    @Test
    public void recibeAxeCounterAttackTest() {
        mbo.recibeAxeCounterAttack(ax);
        assertEquals(5,sorcererO.getCurrentHitPoints());
    }

    @Test
    public void recibeBowCounterAttackTest() {
        mbl.recibeBowCounterAttack(bw);
        assertEquals(15,sorcererL.getCurrentHitPoints());
    }

    @Test
    public void recibeSpearCounterAttackTest() {
        mba.recibeSpearCounterAttack(sp);
        assertEquals(8,sorcererA.getCurrentHitPoints());

    }

    @Test
    public void recibeSwordCounterAttackTest() {
        mbo.recibeSwordCounterAttack(sw);
        assertEquals(13,sorcererO.getCurrentHitPoints());

    }


}
