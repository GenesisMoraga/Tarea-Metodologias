package model.items;
import model.map.Location;
import model.units.Archer;
import model.units.Cleric;
import model.units.IUnit;
import model.units.Sorcerer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class MagicBookLuzTest {
    private IUnit
            cleric,
            archer,
            sorcererA,
            sorcererL,
            sorcererO;
    private MagicBookAnima mba;
    private MagicBookLuz mbl;
    private MagicBookOscuridad mbo;
    private Staff st;
    private Bow bw;

    @BeforeEach
    public void setUp() {
        st=new Staff("st",12,2,3);
        bw= new Bow("bw",22,0,4);
        mba= new MagicBookAnima("a",30,1,3);
        mbl=  new MagicBookLuz("l",20,1,4);
        mbo= new MagicBookOscuridad("o",25,1,2);
        cleric = new Cleric(50,1, new Location(1,0), st);
        archer= new Archer(32,1,new Location(0,0),bw);
        sorcererA= new Sorcerer(50,1,new Location(1,0),mba);
        sorcererL= new Sorcerer(45,1,new Location(1,1),mbl);
        sorcererO= new Sorcerer(30,1,new Location(1,2),mbo);

        bw.setOwner(archer);
        st.setOwner(cleric);
        mba.setOwner(sorcererA);
        mbl.setOwner(sorcererL);
        mbo.setOwner(sorcererO);

        cleric.setEquippedItem(st);
        archer.setEquippedItem(bw);
        sorcererA.setEquippedItem(mba);
        sorcererO.setEquippedItem(mbo);
        sorcererL.setEquippedItem(mbl);
    }

    @Test
    public void constTest() {
        assertEquals(20,mbl.getPower());
        assertEquals(1,mbl.getMinRange());
        assertEquals(4,mbl.getMaxRange());
    }

    @Test
    public void attackTest() {
        mbl.attack(archer);
        assertEquals(2,archer.getCurrentHitPoints());

    }

    @Test
    public void counterAttackTest(){
        mbl.counterAttack(sorcererO);
        assertEquals(0,sorcererO.getCurrentHitPoints());
    }

    @Test
    public void recibeMagicBookAnimaAttackTest() {
        mbl.recibeMagicBookAnimaAttack(mba);
        assertEquals(0,sorcererL.getCurrentHitPoints());
    }

    @Test
    public void recibeMagicBookOscuridadAttackTest() {
        mbl.recibeMagicBookOscuridadAttack(mbo);
        assertEquals(40,sorcererL.getCurrentHitPoints());
    }

    @Test
    public void recibeMagicBookAnimaCounterAttackTest() {
        mbl.recibeMagicBookAnimaCounterAttack(mba);
        assertEquals(0,sorcererL.getCurrentHitPoints());
    }

    @Test
    public void recibeMagicBookOscuridadCounterAttackTest() {
        mbl.recibeMagicBookOscuridadCounterAttack(mbo);
        assertEquals(40,sorcererL.getCurrentHitPoints());
    }
}
